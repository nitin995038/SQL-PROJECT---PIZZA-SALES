-- Analyze the cumulative revenue generated over time.


select order_date,  revenue_date, sum(revenue_date) over(order by order_date) as cum_revenue
from
(select 
orders.order_date, round(sum(pizzas.price*order_details.quantity),2) as revenue_date
from orders join order_details
on orders.order_id=order_details.order_id
join pizzas
on pizzas.pizza_id=order_details.pizza_id
group by orders.order_date) as sales;